<?php

return [
    'table-dispositius' => 'Registro de dispositivos',
    'buttons' => [
        'create' => 'Añadir tiquet',
        'filter' => 'Filtrar'
    ]
];