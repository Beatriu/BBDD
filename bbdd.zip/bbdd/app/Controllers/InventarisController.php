<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class InventarisController extends BaseController
{
    public function index()
    {
        //
    }
}
