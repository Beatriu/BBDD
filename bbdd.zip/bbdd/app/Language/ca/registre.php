<?php

return [
    'table-dispositius' => 'Registre de dispositius',
    'buttons' => [
        'create' => 'Afegir tiquet',
        'filter' => 'Filtrar'
    ]
];