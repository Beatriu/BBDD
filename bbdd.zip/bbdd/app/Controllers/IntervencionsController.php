<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class IntervencionsController extends BaseController
{
    public function index()
    {
        //
    }
}
