<?php

return [
    'table-dispositius' => 'Registre de dispositius',
    'buttons' => [
        'create' => 'Afegir tiquet',
        'filter' => 'Filtrar'
    ],
    'codi_equip' => 'Codi del equip',
    'tipus_dispositiu' => 'Tipus de dispositiu',
    'descripcio_avaria' => 'Descripció',
    'estat' => 'Estat',
    'centre' => 'Centre emissor',
    'centre_reparador' =>'Centre reparador',
    'data_alta' => 'Data de creació'
];